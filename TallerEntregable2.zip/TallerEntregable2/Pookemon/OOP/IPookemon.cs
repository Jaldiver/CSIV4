using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Text;

namespace Pookemon.OOP{
    public interface IPookemon{
        void pDatos();
    }
}